<?php
!defined('ABSPATH') and exit;

// autoload
require_once( WOOZONE_ABSPATH . 'melib/autoload-common.php' );
